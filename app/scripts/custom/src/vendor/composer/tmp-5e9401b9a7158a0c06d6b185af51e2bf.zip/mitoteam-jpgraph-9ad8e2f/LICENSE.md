 Original JpGraph library licensed under QPL 1.0 (Qt Free License) for non-commercial usage.
 
 * Details: https://jpgraph.net/download/
 * QPL 1.0 license: https://opensource.org/licenses/qtpl.php

All additions and patches from MiTo Team are licensed under [MIT License](https://opensource.org/licenses/MIT):
 
 * Composer package and config
 * MtJpGraph class (library loader)
 * All library code patches (diff between original and main branches)
